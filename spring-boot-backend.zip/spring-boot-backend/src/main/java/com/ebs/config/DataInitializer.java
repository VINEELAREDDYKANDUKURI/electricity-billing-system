package com.ebs.config;

import com.ebs.entity.Bill;
import com.ebs.entity.Customer;
import com.ebs.repository.BillRepository;
import com.ebs.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create Admin User
        if (!customerRepository.existsByUsername("admin")) {
            Customer admin = new Customer();
            admin.setConsumerNumber("ADMIN001");
            admin.setName("System Administrator");
            admin.setEmail("admin@ebs.com");
            admin.setMobileNumber("9999999999");
            admin.setConnectionType(Customer.ConnectionType.COMMERCIAL);
            admin.setConnectionStatus(Customer.ConnectionStatus.CONNECTED);
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole(Customer.Role.ROLE_ADMIN);
            customerRepository.save(admin);
            System.out.println("Admin user created: username=admin, password=admin123");
        }

        // Create Sample Customer 1
        if (!customerRepository.existsByUsername("customer1")) {
            Customer customer1 = new Customer();
            customer1.setConsumerNumber("CONS001");
            customer1.setName("John Doe");
            customer1.setEmail("john.doe@email.com");
            customer1.setMobileNumber("9876543210");
            customer1.setConnectionType(Customer.ConnectionType.DOMESTIC);
            customer1.setConnectionStatus(Customer.ConnectionStatus.CONNECTED);
            customer1.setUsername("customer1");
            customer1.setPassword(passwordEncoder.encode("customer123"));
            customer1.setRole(Customer.Role.ROLE_CUSTOMER);
            customer1 = customerRepository.save(customer1);
            System.out.println("Customer 1 created: username=customer1, password=customer123");

            // Create sample bills for customer1
            Bill bill1 = new Bill();
            bill1.setBillNumber("BILL-00000001");
            bill1.setBillingPeriod("December 2024");
            bill1.setBillDate(LocalDate.of(2024, 12, 1));
            bill1.setDueDate(LocalDate.of(2024, 12, 15));
            bill1.setBillAmount(new BigDecimal("1500.00"));
            bill1.setLateFee(BigDecimal.ZERO);
            bill1.setBillStatus(Bill.BillStatus.UNPAID);
            bill1.setCustomer(customer1);
            billRepository.save(bill1);

            Bill bill2 = new Bill();
            bill2.setBillNumber("BILL-00000002");
            bill2.setBillingPeriod("January 2025");
            bill2.setBillDate(LocalDate.of(2025, 1, 1));
            bill2.setDueDate(LocalDate.of(2025, 1, 15));
            bill2.setBillAmount(new BigDecimal("1750.50"));
            bill2.setLateFee(new BigDecimal("50.00"));
            bill2.setBillStatus(Bill.BillStatus.UNPAID);
            bill2.setCustomer(customer1);
            billRepository.save(bill2);

            System.out.println("Sample bills created for customer1");
        }

        // Create Sample Customer 2
        if (!customerRepository.existsByUsername("customer2")) {
            Customer customer2 = new Customer();
            customer2.setConsumerNumber("CONS002");
            customer2.setName("Jane Smith");
            customer2.setEmail("jane.smith@email.com");
            customer2.setMobileNumber("9876543211");
            customer2.setConnectionType(Customer.ConnectionType.COMMERCIAL);
            customer2.setConnectionStatus(Customer.ConnectionStatus.CONNECTED);
            customer2.setUsername("customer2");
            customer2.setPassword(passwordEncoder.encode("customer123"));
            customer2.setRole(Customer.Role.ROLE_CUSTOMER);
            customer2 = customerRepository.save(customer2);
            System.out.println("Customer 2 created: username=customer2, password=customer123");

            // Create sample bill for customer2
            Bill bill3 = new Bill();
            bill3.setBillNumber("BILL-00000003");
            bill3.setBillingPeriod("January 2025");
            bill3.setBillDate(LocalDate.of(2025, 1, 1));
            bill3.setDueDate(LocalDate.of(2025, 1, 20));
            bill3.setBillAmount(new BigDecimal("5500.00"));
            bill3.setLateFee(BigDecimal.ZERO);
            bill3.setBillStatus(Bill.BillStatus.UNPAID);
            bill3.setCustomer(customer2);
            billRepository.save(bill3);

            System.out.println("Sample bill created for customer2");
        }

        System.out.println("\n=== Initial Data Loaded Successfully ===");
        System.out.println("Test Credentials:");
        System.out.println("Admin: username=admin, password=admin123");
        System.out.println("Customer 1: username=customer1, password=customer123");
        System.out.println("Customer 2: username=customer2, password=customer123");
        System.out.println("==========================================\n");
    }
}
