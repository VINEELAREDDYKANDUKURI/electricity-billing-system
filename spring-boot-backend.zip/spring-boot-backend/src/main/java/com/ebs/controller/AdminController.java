package com.ebs.controller;

import com.ebs.dto.AddBillRequest;
import com.ebs.dto.AddBillResponse;
import com.ebs.service.BillService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private BillService billService;

    /**
     * US015 - Add Bill (Admin)
     * POST /api/admin/bill
     * Admin can add bills for customers using consumer number
     */
    @PostMapping("/bill")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AddBillResponse> addBill(@Valid @RequestBody AddBillRequest request) {
        AddBillResponse response = billService.addBill(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}
