package com.ebs.controller;

import com.ebs.dto.LoginRequest;
import com.ebs.dto.LoginResponse;
import com.ebs.entity.Customer;
import com.ebs.security.CustomUserDetailsService;
import com.ebs.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.getUsername(),
                            request.getPassword()
                    )
            );

            // ✅ FIX: Set authentication in security context
            SecurityContextHolder.getContext().setAuthentication(authentication);

            UserDetails userDetails =
                    userDetailsService.loadUserByUsername(request.getUsername());

            Customer customer =
                    userDetailsService.getCustomerByUsername(request.getUsername());

            String token = jwtUtil.generateToken(userDetails);

            LoginResponse response = new LoginResponse(
                    token,
                    customer.getUsername(),
                    customer.getRole().name()
            );

            return ResponseEntity.ok(response);

        } catch (BadCredentialsException e) {
            throw new BadCredentialsException("Invalid username or password");
        }
    }
}
