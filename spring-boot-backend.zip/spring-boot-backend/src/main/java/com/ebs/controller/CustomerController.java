package com.ebs.controller;

import com.ebs.dto.*;
import com.ebs.entity.Customer;
import com.ebs.security.CustomUserDetailsService;
import com.ebs.service.BillService;
import com.ebs.service.InvoiceService;
import com.ebs.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@CrossOrigin(origins = "*")
public class CustomerController {

    @Autowired
    private BillService billService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    /**
     * US003 - View Bills (Customer)
     * GET /api/customer/bills
     * Returns all unpaid bills by default
     */
    @GetMapping("/bills")
    public ResponseEntity<List<BillResponse>> getCustomerBills(
            @RequestParam(value = "unpaidOnly", defaultValue = "true") boolean unpaidOnly) {
        
        Long customerId = getCurrentCustomerId();
        List<BillResponse> bills = billService.getCustomerBills(customerId, unpaidOnly);
        return ResponseEntity.ok(bills);
    }

    /**
     * US004 - View Bill Summary
     * POST /api/customer/bills/summary
     * Returns summary of selected bills with total payable amount
     */
    @PostMapping("/bills/summary")
    public ResponseEntity<BillSummaryResponse> getBillSummary(@RequestBody BillSummaryRequest request) {
        Long customerId = getCurrentCustomerId();
        BillSummaryResponse summary = billService.getBillSummary(customerId, request.getBillIds());
        return ResponseEntity.ok(summary);
    }

    /**
     * US005 - Pay Bill
     * POST /api/customer/pay
     * Process payment for selected bills
     */
    @PostMapping("/pay")
    public ResponseEntity<PaymentResponse> payBill(@Valid @RequestBody PaymentRequest request) {
        Long customerId = getCurrentCustomerId();
        PaymentResponse response = paymentService.processPayment(customerId, request);
        return ResponseEntity.ok(response);
    }

    /**
     * US006 - Generate Invoice
     * GET /api/customer/invoice/{paymentId}
     * Generate invoice after successful payment
     */
    @GetMapping("/invoice/{paymentId}")
    public ResponseEntity<InvoiceResponse> generateInvoice(@PathVariable Long paymentId) {
        Long customerId = getCurrentCustomerId();
        InvoiceResponse invoice = invoiceService.generateInvoice(customerId, paymentId);
        return ResponseEntity.ok(invoice);
    }

    // Helper method to get current logged-in customer ID
    private Long getCurrentCustomerId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Customer customer = userDetailsService.getCustomerByUsername(username);
        return customer.getCustomerId();
    }
}
