package com.ebs.service.impl;

import com.ebs.dto.*;
import com.ebs.entity.Bill;
import com.ebs.entity.Customer;
import com.ebs.exception.DuplicateBillException;
import com.ebs.exception.InvalidBillException;
import com.ebs.exception.ResourceNotFoundException;
import com.ebs.repository.BillRepository;
import com.ebs.repository.CustomerRepository;
import com.ebs.service.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class BillServiceImpl implements BillService {

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public List<BillResponse> getCustomerBills(Long customerId, boolean unpaidOnly) {

        // Validate customer exists
        customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));

        List<Bill> bills = unpaidOnly
                ? billRepository.findByCustomerCustomerIdAndBillStatus(customerId, Bill.BillStatus.UNPAID)
                : billRepository.findByCustomerCustomerId(customerId);

        return bills.stream()
                .map(this::mapToBillResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BillSummaryResponse getBillSummary(Long customerId, List<Long> billIds) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));

        List<Bill> bills = billRepository.findByBillIdIn(billIds);

        if (bills.isEmpty()) {
            throw new InvalidBillException("No valid bills found");
        }

        for (Bill bill : bills) {
            if (!bill.getCustomer().getCustomerId().equals(customerId)) {
                throw new InvalidBillException(
                        "Bill " + bill.getBillNumber() + " does not belong to this customer");
            }
        }

        BillSummaryResponse response = new BillSummaryResponse();
        response.setConsumerNumber(customer.getConsumerNumber());
        response.setCustomerName(customer.getName());
        response.setTotalBills(bills.size());

        List<BillSummaryResponse.BillDetailDto> details = bills.stream()
                .map(bill -> {
                    BillSummaryResponse.BillDetailDto dto = new BillSummaryResponse.BillDetailDto();
                    dto.setBillId(bill.getBillId());
                    dto.setBillNumber(bill.getBillNumber());
                    dto.setBillingPeriod(bill.getBillingPeriod());
                    dto.setBillAmount(bill.getBillAmount().add(bill.getLateFee()));
                    dto.setDueDate(bill.getDueDate().toString());
                    return dto;
                })
                .collect(Collectors.toList());

        response.setBills(details);

        BigDecimal totalAmount = bills.stream()
                .map(b -> b.getBillAmount().add(b.getLateFee()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        response.setTotalAmount(totalAmount);

        return response;
    }

    @Override
    public AddBillResponse addBill(AddBillRequest request) {

        Customer customer = customerRepository.findByConsumerNumber(request.getConsumerNumber())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Customer", "consumerNumber", request.getConsumerNumber()));

        if (!request.getDueDate().isAfter(request.getBillDate())) {
            throw new InvalidBillException("Due date must be after bill date");
        }

        if (billRepository.existsByCustomerConsumerNumberAndBillingPeriod(
                request.getConsumerNumber(), request.getBillingPeriod())) {
            throw new DuplicateBillException(
                    request.getConsumerNumber(), request.getBillingPeriod());
        }

        Bill bill = new Bill();
        bill.setBillNumber("BILL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        bill.setBillingPeriod(request.getBillingPeriod());
        bill.setBillDate(request.getBillDate());
        bill.setDueDate(request.getDueDate());
        bill.setBillAmount(request.getBillAmount());
        bill.setLateFee(request.getLateFee() != null ? request.getLateFee() : BigDecimal.ZERO);
        bill.setBillStatus(Bill.BillStatus.UNPAID);
        bill.setCustomer(customer);

        Bill savedBill = billRepository.save(bill);

        AddBillResponse response = new AddBillResponse();
        response.setMessage("Bill added successfully");
        response.setBillId(savedBill.getBillId());
        response.setBillNumber(savedBill.getBillNumber());
        response.setConsumerNumber(customer.getConsumerNumber());
        response.setBillingPeriod(savedBill.getBillingPeriod());
        response.setBillDate(savedBill.getBillDate());
        response.setDueDate(savedBill.getDueDate());
        response.setBillAmount(savedBill.getBillAmount());
        response.setLateFee(savedBill.getLateFee());
        response.setBillStatus(savedBill.getBillStatus().name());

        return response;
    }

    private BillResponse mapToBillResponse(Bill bill) {
        BillResponse response = new BillResponse();
        response.setBillId(bill.getBillId());
        response.setConsumerNumber(bill.getCustomer().getConsumerNumber());
        response.setBillNumber(bill.getBillNumber());
        response.setBillingPeriod(bill.getBillingPeriod());
        response.setBillDate(bill.getBillDate());
        response.setDueDate(bill.getDueDate());
        response.setBillAmount(bill.getBillAmount());
        response.setLateFee(bill.getLateFee());
        response.setBillStatus(bill.getBillStatus().name());
        response.setConnectionType(bill.getCustomer().getConnectionType().name());
        response.setConnectionStatus(bill.getCustomer().getConnectionStatus().name());
        response.setCustomerName(bill.getCustomer().getName());
        response.setMobileNumber(bill.getCustomer().getMobileNumber());
        return response;
    }
}
