package com.ebs.service;

import com.ebs.dto.*;



import java.util.List;

public interface BillService {
    
    // US003 - View Bills (Customer)
    List<BillResponse> getCustomerBills(Long customerId, boolean unpaidOnly);
    
    // US004 - View Bill Summary
    BillSummaryResponse getBillSummary(Long customerId, List<Long> billIds);
    
    // US015 - Add Bill (Admin)
    AddBillResponse addBill(AddBillRequest request);
}
