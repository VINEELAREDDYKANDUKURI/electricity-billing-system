package com.ebs.service;

import com.ebs.dto.PaymentRequest;
import com.ebs.dto.PaymentResponse;

public interface PaymentService {
    
    // US005 - Pay Bill
    PaymentResponse processPayment(Long customerId, PaymentRequest request);
}
