package com.ebs.service.impl;

import com.ebs.dto.InvoiceResponse;
import com.ebs.entity.Bill;
import com.ebs.entity.Customer;
import com.ebs.entity.Invoice;
import com.ebs.entity.Payment;
import com.ebs.exception.InvalidPaymentException;
import com.ebs.exception.ResourceNotFoundException;
import com.ebs.repository.CustomerRepository;
import com.ebs.repository.InvoiceRepository;
import com.ebs.repository.PaymentRepository;
import com.ebs.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public InvoiceResponse generateInvoice(Long customerId, Long paymentId) {
        // Validate customer exists
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));

        // Fetch payment
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "id", paymentId));

        // Validate payment belongs to customer's bill
        Bill bill = payment.getBill();
        if (!bill.getCustomer().getCustomerId().equals(customerId)) {
            throw new InvalidPaymentException("Payment does not belong to this customer");
        }

        // Validate payment was successful
        if (payment.getPaymentStatus() != Payment.PaymentStatus.SUCCESS) {
            throw new InvalidPaymentException("Cannot generate invoice for failed payment");
        }

        // Check if invoice already exists
        Invoice invoice = invoiceRepository.findByPaymentPaymentId(paymentId).orElse(null);

        if (invoice == null) {
            // Generate new invoice
            String invoiceNumber = "INV-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            
            invoice = new Invoice();
            invoice.setInvoiceNumber(invoiceNumber);
            invoice.setGeneratedDate(LocalDateTime.now());
            invoice.setPayment(payment);
            
            invoice = invoiceRepository.save(invoice);
        }

        // Build response
        InvoiceResponse response = new InvoiceResponse();
        response.setInvoiceNumber(invoice.getInvoiceNumber());
        response.setGeneratedDate(invoice.getGeneratedDate());

        // Consumer Details
        response.setConsumerNumber(customer.getConsumerNumber());
        response.setCustomerName(customer.getName());
        response.setEmail(customer.getEmail());
        response.setMobileNumber(customer.getMobileNumber());

        // Transaction Details
        response.setTransactionId(payment.getTransactionId());
        response.setTransactionDate(payment.getPaymentDate());
        response.setPaymentMode(payment.getPaymentMode().name());
        response.setPaymentStatus(payment.getPaymentStatus().name());
        response.setReceiptNumber(payment.getReceiptNumber());

        // Bill Details
        response.setBillNumber(bill.getBillNumber());
        response.setBillingPeriod(bill.getBillingPeriod());
        response.setBillAmount(bill.getBillAmount());
        response.setLateFee(bill.getLateFee());
        response.setTotalAmount(payment.getAmount());

        return response;
    }
}
