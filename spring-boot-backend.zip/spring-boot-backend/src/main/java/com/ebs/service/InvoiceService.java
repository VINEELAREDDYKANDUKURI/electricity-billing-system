package com.ebs.service;

import com.ebs.dto.InvoiceResponse;

public interface InvoiceService {
    
    // US006 - Generate Invoice
    InvoiceResponse generateInvoice(Long customerId, Long paymentId);
}
