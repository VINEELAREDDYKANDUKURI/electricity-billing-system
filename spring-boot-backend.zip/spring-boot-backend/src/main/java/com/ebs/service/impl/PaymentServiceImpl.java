package com.ebs.service.impl;

import com.ebs.dto.PaymentRequest;
import com.ebs.dto.PaymentResponse;
import com.ebs.entity.Bill;
import com.ebs.entity.Payment;
import com.ebs.exception.InvalidPaymentException;
import com.ebs.exception.ResourceNotFoundException;
import com.ebs.repository.BillRepository;
import com.ebs.repository.CustomerRepository;
import com.ebs.repository.PaymentRepository;
import com.ebs.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BillRepository billRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public PaymentResponse processPayment(Long customerId, PaymentRequest request) {

        // Validate customer exists
    	customerRepository.findById(customerId)
        .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));

        // Validate payment mode
        Payment.PaymentMode paymentMode;
        try {
            paymentMode = Payment.PaymentMode.valueOf(request.getPaymentMode().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new InvalidPaymentException(
                    "Invalid payment mode. Allowed: CREDIT, DEBIT, NET_BANKING");
        }

        // Validate card details for CREDIT / DEBIT
        if (paymentMode == Payment.PaymentMode.CREDIT || paymentMode == Payment.PaymentMode.DEBIT) {
            validateCardDetails(request);
        }

        // Fetch bills
        List<Bill> bills = billRepository.findByBillIdIn(request.getBillIds());
        if (bills.isEmpty()) {
            throw new ResourceNotFoundException("Bills", "ids", request.getBillIds());
        }

        BigDecimal totalAmount = BigDecimal.ZERO;
        List<String> paidBillNumbers = new ArrayList<>();

        // Validate bills
        for (Bill bill : bills) {
            if (!bill.getCustomer().getCustomerId().equals(customerId)) {
                throw new InvalidPaymentException(
                        "Bill does not belong to this customer: " + bill.getBillNumber());
            }
            if (bill.getBillStatus() == Bill.BillStatus.PAID) {
                throw new InvalidPaymentException(
                        "Bill already paid: " + bill.getBillNumber());
            }
            totalAmount = totalAmount
                    .add(bill.getBillAmount())
                    .add(bill.getLateFee());
        }

        // Generate single transaction & receipt
        String transactionId = "TXN-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
        String receiptNumber = "RCP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        LocalDateTime paymentDate = LocalDateTime.now();

        Payment lastPayment = null;

        // Process payment for each bill
        for (Bill bill : bills) {
            Payment payment = new Payment();
            payment.setTransactionId(transactionId);
            payment.setReceiptNumber(receiptNumber);
            payment.setPaymentDate(paymentDate);
            payment.setPaymentMode(paymentMode);
            payment.setAmount(bill.getBillAmount().add(bill.getLateFee()));
            payment.setPaymentStatus(Payment.PaymentStatus.SUCCESS);
            payment.setBill(bill);
           

            paymentRepository.save(payment);
            lastPayment = payment;

            // Update bill status
            bill.setBillStatus(Bill.BillStatus.PAID);
            billRepository.save(bill);

            paidBillNumbers.add(bill.getBillNumber());
        }

        // Build response
        PaymentResponse response = new PaymentResponse();
        response.setMessage("Payment successful");
        response.setPaymentId(lastPayment.getPaymentId());
        response.setTransactionId(transactionId);
        response.setReceiptNumber(receiptNumber);
        response.setTransactionDate(paymentDate);
        response.setPaymentMode(paymentMode.name());
        response.setTotalAmount(totalAmount);
        response.setPaymentStatus("SUCCESS");
        response.setPaidBillNumbers(paidBillNumbers);

        return response;
    }

    private void validateCardDetails(PaymentRequest request) {
        if (request.getCardNumber() == null || request.getCardNumber().length() != 16) {
            throw new InvalidPaymentException("Card number must be 16 digits");
        }

        if (request.getCvv() == null || (request.getCvv().length() != 3 && request.getCvv().length() != 4)) {
            throw new InvalidPaymentException("CVV must be 3 or 4 digits");
        }

        if (request.getExpiryDate() == null ||
                !request.getExpiryDate().matches("^(0[1-9]|1[0-2])/([0-9]{2})$")) {
            throw new InvalidPaymentException("Expiry date must be in MM/YY format");
        }

        String[] parts = request.getExpiryDate().split("/");
        int month = Integer.parseInt(parts[0]);
        int year = 2000 + Integer.parseInt(parts[1]);

        YearMonth expiry = YearMonth.of(year, month);
        if (expiry.isBefore(YearMonth.now())) {
            throw new InvalidPaymentException("Card has expired");
        }

        if (request.getCardHolderName() == null || request.getCardHolderName().trim().isEmpty()) {
            throw new InvalidPaymentException("Card holder name is required");
        }
    }
}
