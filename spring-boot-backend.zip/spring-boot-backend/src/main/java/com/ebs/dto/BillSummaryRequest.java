package com.ebs.dto;

import java.util.List;

public class BillSummaryRequest {
    
    private List<Long> billIds;

    // Constructors
    public BillSummaryRequest() {}

    public BillSummaryRequest(List<Long> billIds) {
        this.billIds = billIds;
    }

    // Getters and Setters
    public List<Long> getBillIds() {
        return billIds;
    }

    public void setBillIds(List<Long> billIds) {
        this.billIds = billIds;
    }
}
