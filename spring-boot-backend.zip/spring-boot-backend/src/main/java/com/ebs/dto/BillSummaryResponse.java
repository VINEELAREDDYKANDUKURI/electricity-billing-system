package com.ebs.dto;

import java.math.BigDecimal;
import java.util.List;

public class BillSummaryResponse {
    
    private String consumerNumber;
    private String customerName;
    private List<BillDetailDto> bills;
    private BigDecimal totalAmount;
    private int totalBills;

    // Constructors
    public BillSummaryResponse() {}

    // Inner class for bill details
    public static class BillDetailDto {
        private Long billId;
        private String billNumber;
        private String billingPeriod;
        private BigDecimal billAmount;
        private String dueDate;

        public BillDetailDto() {}

        public Long getBillId() {
            return billId;
        }

        public void setBillId(Long billId) {
            this.billId = billId;
        }

        public String getBillNumber() {
            return billNumber;
        }

        public void setBillNumber(String billNumber) {
            this.billNumber = billNumber;
        }

        public String getBillingPeriod() {
            return billingPeriod;
        }

        public void setBillingPeriod(String billingPeriod) {
            this.billingPeriod = billingPeriod;
        }

        public BigDecimal getBillAmount() {
            return billAmount;
        }

        public void setBillAmount(BigDecimal billAmount) {
            this.billAmount = billAmount;
        }

        public String getDueDate() {
            return dueDate;
        }

        public void setDueDate(String dueDate) {
            this.dueDate = dueDate;
        }
    }

    // Getters and Setters
    public String getConsumerNumber() {
        return consumerNumber;
    }

    public void setConsumerNumber(String consumerNumber) {
        this.consumerNumber = consumerNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public List<BillDetailDto> getBills() {
        return bills;
    }

    public void setBills(List<BillDetailDto> bills) {
        this.bills = bills;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public int getTotalBills() {
        return totalBills;
    }

    public void setTotalBills(int totalBills) {
        this.totalBills = totalBills;
    }
}
