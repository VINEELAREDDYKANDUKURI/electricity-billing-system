package com.ebs.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class AddBillRequest {
    
    @NotBlank(message = "Consumer number is required")
    private String consumerNumber;

    @NotBlank(message = "Billing period is required")
    private String billingPeriod; // e.g., "January 2024"

    @NotNull(message = "Bill date is required")
    private LocalDate billDate;

    @NotNull(message = "Due date is required")
    private LocalDate dueDate;

    @NotNull(message = "Bill amount is required")
    @DecimalMin(value = "0.01", message = "Bill amount must be greater than 0")
    private BigDecimal billAmount;

    @DecimalMin(value = "0.00", message = "Late fee cannot be negative")
    private BigDecimal lateFee = BigDecimal.ZERO;

    private String billStatus = "UNPAID"; // Default to UNPAID

    // Constructors
    public AddBillRequest() {}

    // Getters and Setters
    public String getConsumerNumber() {
        return consumerNumber;
    }

    public void setConsumerNumber(String consumerNumber) {
        this.consumerNumber = consumerNumber;
    }

    public String getBillingPeriod() {
        return billingPeriod;
    }

    public void setBillingPeriod(String billingPeriod) {
        this.billingPeriod = billingPeriod;
    }

    public LocalDate getBillDate() {
        return billDate;
    }

    public void setBillDate(LocalDate billDate) {
        this.billDate = billDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getBillAmount() {
        return billAmount;
    }

    public void setBillAmount(BigDecimal billAmount) {
        this.billAmount = billAmount;
    }

    public BigDecimal getLateFee() {
        return lateFee;
    }

    public void setLateFee(BigDecimal lateFee) {
        this.lateFee = lateFee;
    }

    public String getBillStatus() {
        return billStatus;
    }

    public void setBillStatus(String billStatus) {
        this.billStatus = billStatus;
    }
}
