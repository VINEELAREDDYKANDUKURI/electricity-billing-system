package com.ebs.repository;

import com.ebs.entity.Bill;
import com.ebs.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {
    
    List<Bill> findByCustomer(Customer customer);
    
    List<Bill> findByCustomerAndBillStatus(Customer customer, Bill.BillStatus billStatus);
    
    List<Bill> findByCustomerCustomerId(Long customerId);
    
    List<Bill> findByCustomerCustomerIdAndBillStatus(Long customerId, Bill.BillStatus billStatus);
    
    Optional<Bill> findByBillNumber(String billNumber);
    
    boolean existsByBillNumber(String billNumber);
    
    boolean existsByCustomerConsumerNumberAndBillingPeriod(String consumerNumber, String billingPeriod);
    
    List<Bill> findByBillIdIn(List<Long> billIds);
}
