package com.ebs.repository;

import com.ebs.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    
    Optional<Customer> findByUsername(String username);
    
    Optional<Customer> findByConsumerNumber(String consumerNumber);
    
    boolean existsByConsumerNumber(String consumerNumber);
    
    boolean existsByUsername(String username);
    
    boolean existsByEmail(String email);
}
