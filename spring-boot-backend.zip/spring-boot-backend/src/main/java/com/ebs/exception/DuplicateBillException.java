package com.ebs.exception;

public class DuplicateBillException extends RuntimeException {
    
	private static final long serialVersionUID = 1L ;
    private String consumerNumber;
    private String billingPeriod;

    public DuplicateBillException(String consumerNumber, String billingPeriod) {
        super(String.format("Bill already exists for consumer '%s' for billing period '%s'", 
                consumerNumber, billingPeriod));
        this.consumerNumber = consumerNumber;
        this.billingPeriod = billingPeriod;
    }

    public DuplicateBillException(String message) {
        super(message);
    }

    public String getConsumerNumber() {
        return consumerNumber;
    }

    public String getBillingPeriod() {
        return billingPeriod;
    }
}
